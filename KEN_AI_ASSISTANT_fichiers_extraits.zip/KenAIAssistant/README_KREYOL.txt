KEN AI ASSISTANT – PREMYE VÈSYON TÈS

Sa se kòd sous yon premye pwojè Android, se pa APK ki deja enstale.

Sa li fè:
- Montre yon entèfas nwa/wouj.
- Pèmèt aktive/dezaktive repons otomatik.
- Pèmèt mete non kontak ou otorize.
- Pèmèt chwazi mòd pèsonèl oswa pwofesyonèl.
- Li notifikasyon WhatsApp/Messenger/Telegram epi, si notifikasyon an bay aksyon 'Reply', li ka voye yon repons kout.

LIMIT ENPÒTAN:
- Repons yo se modèl senp pou demonstrasyon; poko gen yon vrè motè AI.
- Li pa kapab li tout mesaj oswa istwa konvèsasyon.
- Li pa garanti fonksyone ak tout vèsyon WhatsApp, Messenger oswa Telegram.
- Li pa dwe sèvi pou voye mesaj san konsantman moun oswa pou kontoune sekirite aplikasyon yo.
- Pa mete non moun nan lis otorize sof si ou dakò pou sistèm nan reponn yo.
- Pa pataje APK ak moun anvan ou teste l.

KREYE APK:
1. Mete dosye pwojè sa yo nan yon depo GitHub.
2. Ale nan onglet Actions.
3. Chwazi workflow 'Build Android APK' epi peze Run workflow.
4. Lè li fini, telechaje artifact 'KEN-AI-ASSISTANT-debug-apk'.
5. Sou telefòn ou, enstale APK la, epi aktive aksè notifikasyon nan paramèt Android.

Pou pwochen vèsyon an, n ap bezwen ajoute vrè AI (ak kle API prive ki pa dwe antre dirèkteman nan APK) epi yon fason sekirize pou jere apwobasyon repons yo.
