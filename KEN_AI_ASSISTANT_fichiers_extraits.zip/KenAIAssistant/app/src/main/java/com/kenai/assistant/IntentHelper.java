package com.kenai.assistant;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

final class IntentHelper {
    static void sendReply(Context context, Notification.Action action, Bundle results) {
        Intent fillIn = new Intent();
        RemoteInput.addResultsToIntent(action.getRemoteInputs(), fillIn, results);
        try { action.actionIntent.send(context, 0, fillIn); }
        catch (Exception ignored) { }
    }
}
