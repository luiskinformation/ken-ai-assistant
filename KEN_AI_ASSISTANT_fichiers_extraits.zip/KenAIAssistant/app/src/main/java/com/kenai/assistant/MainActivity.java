package com.kenai.assistant;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    EditText allowList;
    Switch autoSwitch;
    RadioGroup modeGroup;
    TextView status, inbox;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(12,12,12));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(22, 28, 22, 20);
        page.setBackgroundColor(Color.rgb(12,12,12));

        TextView title = new TextView(this);
        title.setText("KEN AI ASSISTANT");
        title.setTextColor(Color.rgb(235,35,55));
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 8);
        page.addView(title);

        TextView subtitle = label("Asistan mesaj ou • Kreyòl / Français / English");
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle);

        status = label("Estati: verifye aksè notifikasyon an.");
        page.addView(status);

        Button access = button("AKTIVE AKSÈ NOTIFIKASYON");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        page.addView(access);

        autoSwitch = new Switch(this);
        autoSwitch.setText("Repons otomatik (ON/OFF)");
        autoSwitch.setTextColor(Color.WHITE);
        autoSwitch.setTextSize(16);
        autoSwitch.setChecked(getSharedPreferences("ken_ai", MODE_PRIVATE).getBoolean("auto", false));
        autoSwitch.setOnCheckedChangeListener((v, checked) -> getSharedPreferences("ken_ai", MODE_PRIVATE).edit().putBoolean("auto", checked).apply());
        page.addView(autoSwitch);

        TextView modeLabel = label("Mòd repons:");
        page.addView(modeLabel);
        modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton personal = radio("Pèsonèl – pi natirèl");
        personal.setId(1);
        RadioButton pro = radio("Pwofesyonèl – plis fòmèl");
        pro.setId(2);
        modeGroup.addView(personal); modeGroup.addView(pro);
        modeGroup.check(getSharedPreferences("ken_ai", MODE_PRIVATE).getInt("mode", 1));
        modeGroup.setOnCheckedChangeListener((g, id) -> getSharedPreferences("ken_ai", MODE_PRIVATE).edit().putInt("mode", id).apply());
        page.addView(modeGroup);

        page.addView(label("Kontak otorize (separe non yo ak vigil):"));
        allowList = new EditText(this);
        allowList.setTextColor(Color.WHITE);
        allowList.setHintTextColor(Color.GRAY);
        allowList.setHint("Egzanp: Marie, Jean, Paul");
        allowList.setText(getSharedPreferences("ken_ai", MODE_PRIVATE).getString("allow", ""));
        allowList.setSingleLine(false);
        allowList.setMinLines(2);
        allowList.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(220,35,55)));
        page.addView(allowList);

        Button save = button("ANREJISTRE PARAMÈT YO");
        save.setOnClickListener(v -> {
            getSharedPreferences("ken_ai", MODE_PRIVATE).edit().putString("allow", allowList.getText().toString()).apply();
            Toast.makeText(this, "Paramèt yo anrejistre.", Toast.LENGTH_SHORT).show();
        });
        page.addView(save);

        page.addView(label("Dènye mesaj detekte:"));
        inbox = label(getSharedPreferences("ken_ai", MODE_PRIVATE).getString("last", "Pa gen mesaj anrejistre pou kounye a."));
        inbox.setBackgroundColor(Color.rgb(28,28,28));
        inbox.setPadding(12,12,12,12);
        page.addView(inbox);

        TextView note = label("Premye vèsyon tès: li notifikasyon epi li ka reponn sèlman si aplikasyon mesaj la bay yon bouton repons rapid. Li pa li ansyen mesaj ni li pa kontoune sekirite WhatsApp/Messenger.");
        note.setTextSize(12);
        page.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean enabled = false;
        String listeners = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (listeners != null) enabled = listeners.contains(getPackageName());
        if (status != null) status.setText(enabled ? "Estati: aksè notifikasyon aktive ✓" : "Estati: aksè notifikasyon poko aktive");
        if (inbox != null) inbox.setText(getSharedPreferences("ken_ai", MODE_PRIVATE).getString("last", "Pa gen mesaj anrejistre pou kounye a."));
    }

    TextView label(String s) { TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(15); t.setPadding(0,12,0,8); return t; }
    Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,20,40))); return b; }
    RadioButton radio(String s) { RadioButton r=new RadioButton(this); r.setText(s); r.setTextColor(Color.WHITE); return r; }
}
