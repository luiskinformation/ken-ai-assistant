package com.kenai.assistant;

import android.app.Notification;
import android.app.RemoteInput;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import java.util.Locale;

public class MessageListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (!(pkg.contains("whatsapp") || pkg.contains("facebook") || pkg.contains("messenger") ||
              pkg.contains("telegram"))) return;

        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        CharSequence whoCs = n.extras.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence msgCs = n.extras.getCharSequence(Notification.EXTRA_TEXT);
        if (msgCs == null) msgCs = n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (msgCs == null || msgCs.length() == 0) return;

        String who = whoCs == null ? "Kontak" : whoCs.toString();
        String msg = msgCs.toString();
        SharedPreferences p = getSharedPreferences("ken_ai", MODE_PRIVATE);
        p.edit().putString("last", who + ": " + msg).apply();

        if (!p.getBoolean("auto", false)) return;
        String allowed = p.getString("allow", "").toLowerCase(Locale.ROOT);
        if (TextUtils.isEmpty(allowed) || !allowed.contains(who.toLowerCase(Locale.ROOT))) return;

        Notification.Action replyAction = findReplyAction(n);
        if (replyAction == null || replyAction.getRemoteInputs() == null || replyAction.actionIntent == null) return;

        String answer = makeReply(msg, p.getInt("mode", 1));
        Bundle results = new Bundle();
        for (RemoteInput ri : replyAction.getRemoteInputs()) results.putCharSequence(ri.getResultKey(), answer);
        IntentHelper.sendReply(this, replyAction, results);
    }

    private Notification.Action findReplyAction(Notification n) {
        if (n.actions == null) return null;
        for (Notification.Action a : n.actions) {
            if (a.getRemoteInputs() != null && a.actionIntent != null) return a;
        }
        return null;
    }

    private String makeReply(String msg, int mode) {
        String s = msg.toLowerCase(Locale.ROOT);
        boolean french = s.matches("(?s).*(bonjour|merci|comment|salut|bonsoir|ça va|vous).*");
        boolean english = s.matches("(?s).*(hello|hi |how are|thank you|good morning|good evening).*");
        if (french) return mode == 2 ? "Bonjour. Merci pour votre message. Je vous répondrai dès que possible." : "Coucou 😊 Merci pour ton message ! Je te réponds dès que possible.";
        if (english) return mode == 2 ? "Hello. Thank you for your message. I will get back to you as soon as possible." : "Hey 😊 Thanks for your message! I'll get back to you soon.";
        return mode == 2 ? "Bonjou. Mèsi pou mesaj ou. M ap reponn ou dèske sa posib." : "Hey 😊 Mèsi paske ou ekri m! M ap pale avè w talè.";
    }
}
